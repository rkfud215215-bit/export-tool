-- ============================================================
-- 수출 서류 자동화 시스템 - Supabase DB 스키마
-- Supabase 대시보드 → SQL Editor에 전체를 붙여넣고 실행하면 됩니다.
-- ============================================================

-- ────────────────────────────────────────────
-- 1. files 테이블: 메일에서 수집한 원본 첨부파일 메타정보
--    (실제 파일 바이너리는 Supabase Storage에 저장, 여긴 메타데이터만)
-- ────────────────────────────────────────────
create table if not exists files (
  id              uuid primary key default gen_random_uuid(),
  storage_path    text not null,              -- Storage 안에서의 경로 (예: raw/2026-06-18/abc123.pdf)
  original_name   text not null,              -- 메일 첨부 시 원본 파일명
  file_hash       text,                       -- MD5 등 해시값 (중복 체크용)
  file_size_bytes bigint,
  mime_type       text,

  -- 메일 소스 정보 (어떤 메일에서 왔는지 추적용)
  source_type     text not null default 'email',  -- 'email' | 'manual_upload' 등 향후 확장
  mail_account    text,                       -- 수집한 메일함 주소 (예: export@company.com)
  mail_message_id text,                       -- 메일의 Message-ID (중복 수집 방지)
  mail_subject    text,
  mail_received_at timestamptz,

  -- 처리 상태
  status          text not null default 'pending',
    -- pending: 수집됨, 분석 전
    -- analyzing: Gemini 분석 중
    -- analyzed: 분석 완료, 레코드 매핑 대기
    -- matched: 레코드에 매핑 완료
    -- renamed: 파일서버에 리네임/이동 완료
    -- error: 처리 중 오류 발생
  error_message   text,

  -- Gemini 분석 결과 (원본 그대로 보관 — 나중에 재분석/디버깅용)
  doc_type        text,    -- INVOICE | BL | EXPORT | FORWARDER_INVOICE | UNKNOWN
  manual_doc_type text,    -- 수동으로 재지정한 경우(NULL이면 doc_type 그대로 사용)
  invoice_no      text,
  bl_no           text,
  export_no       text,
  decl_date       date,
  buyer           text,
  currency        text,
  amount          text,
  etd             text,
  forwarder       text,
  raw_gemini_json jsonb,   -- Gemini가 반환한 원본 JSON 전체 (디버깅/재처리용)

  -- 리네이밍 결과
  renamed_path    text,    -- 파일서버에 최종 저장된 경로/파일명

  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create index if not exists idx_files_status on files(status);
create index if not exists idx_files_invoice_no on files(invoice_no);
create index if not exists idx_files_bl_no on files(bl_no);
create index if not exists idx_files_mail_message_id on files(mail_message_id);

-- 같은 메일이 중복 수집되는 것을 막기 위한 유니크 제약
-- (mail_message_id + 첨부파일명 조합이 같으면 같은 파일로 간주)
create unique index if not exists uq_files_mail_attachment
  on files(mail_message_id, original_name)
  where mail_message_id is not null;


-- ────────────────────────────────────────────
-- 2. records 테이블: Invoice No 기준으로 묶인 "서류 대장" 레코드
--    (지금 export_tool.html의 서류대장 테이블 1행 = 여기 1행)
-- ────────────────────────────────────────────
create table if not exists records (
  id                    uuid primary key default gen_random_uuid(),
  invoice_no            text not null,        -- 'OT-MA-260201' 또는 '(미확인)'
  bl_no                 text,
  export_no             text,
  decl_date             date,
  buyer                 text,
  currency              text,
  amount                text,
  etd                   text,
  forwarder             text,

  has_invoice           boolean not null default false,
  has_bl                boolean not null default false,
  has_export             boolean not null default false,
  has_forwarder_invoice boolean not null default false,

  is_complete           boolean not null default false,
  missing_docs          text[] not null default '{}',

  duplicates            boolean not null default false,
  bl_match_failed        boolean not null default false,
  match_fail_reasons     text[] not null default '{}',
  manually_merged        boolean not null default false,

  memo                  text,                 -- 사용자가 입력한 비고

  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

create index if not exists idx_records_invoice_no on records(invoice_no);
create index if not exists idx_records_bl_no on records(bl_no);
create index if not exists idx_records_is_complete on records(is_complete);


-- ────────────────────────────────────────────
-- 3. record_files 테이블: records ↔ files 다대다 연결
--    (지금 export_tool.html의 fileEntries 배열에 해당)
-- ────────────────────────────────────────────
create table if not exists record_files (
  id          uuid primary key default gen_random_uuid(),
  record_id   uuid not null references records(id) on delete cascade,
  file_id     uuid not null references files(id) on delete cascade,
  matched_by  text not null default 'NONE',
    -- INVOICE | INV_IN_TEXT | BL_MATCH | BL_GROUP | MANUAL | NONE
  rename_suggestion text,   -- 이 파일에 대한 리네이밍 제안 (BL.pdf, INV_xxx.pdf 등)
  created_at  timestamptz not null default now(),

  unique(record_id, file_id)
);

create index if not exists idx_record_files_record_id on record_files(record_id);
create index if not exists idx_record_files_file_id on record_files(file_id);


-- ────────────────────────────────────────────
-- 4. processing_log 테이블: 파이프라인 실행 이력 (모니터링/디버깅용)
-- ────────────────────────────────────────────
create table if not exists processing_log (
  id           uuid primary key default gen_random_uuid(),
  stage        text not null,   -- 'mail_collect' | 'gemini_analyze' | 'rename_move'
  status       text not null,   -- 'success' | 'error'
  detail       text,
  files_count  integer default 0,
  started_at   timestamptz not null default now(),
  finished_at  timestamptz
);

create index if not exists idx_processing_log_stage on processing_log(stage);
create index if not exists idx_processing_log_started_at on processing_log(started_at desc);


-- ────────────────────────────────────────────
-- 5. updated_at 자동 갱신 트리거 (files, records 공통)
-- ────────────────────────────────────────────
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_files_updated_at on files;
create trigger trg_files_updated_at
  before update on files
  for each row execute function set_updated_at();

drop trigger if exists trg_records_updated_at on records;
create trigger trg_records_updated_at
  before update on records
  for each row execute function set_updated_at();


-- ────────────────────────────────────────────
-- 6. Storage 버킷 생성 (원본 첨부파일 보관용)
--    SQL Editor에서는 버킷 생성이 안 되므로, 아래는 참고용 안내입니다.
--    실제로는 Supabase 대시보드 → Storage → New bucket 에서
--    이름 "export-docs" (private)로 만들어주세요.
-- ────────────────────────────────────────────
-- insert into storage.buckets (id, name, public) values ('export-docs', 'export-docs', false);


-- ────────────────────────────────────────────
-- 7. Row Level Security (RLS) — 일단 서비스 키로만 접근하는 내부 도구이므로
--    RLS는 켜두고 "서비스 역할(service_role)"만 전체 접근 허용.
--    (Edge Function은 서비스 키를 쓰므로 영향 없음. 프론트엔드에서
--     anon key로 직접 DB를 만지게 하려면 나중에 정책을 더 세밀하게 추가)
-- ────────────────────────────────────────────
alter table files enable row level security;
alter table records enable row level security;
alter table record_files enable row level security;
alter table processing_log enable row level security;

-- 서비스 역할(백엔드, Edge Function)은 항상 전체 접근 가능 (기본 동작이라 정책 불필요)
-- 프론트엔드(anon key)에서 읽기만 허용하고 싶다면 아래 주석을 해제하세요.
-- create policy "anon can read files" on files for select using (true);
-- create policy "anon can read records" on records for select using (true);
-- create policy "anon can read record_files" on record_files for select using (true);
