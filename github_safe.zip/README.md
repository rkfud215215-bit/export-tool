# 수출 서류 자동 수집·분석 시스템

메일로 들어오는 수출 관련 서류(B/L, 포워더 청구서, 수출신고필증 등)를 자동으로
수집하고, Gemini AI로 분석해서 Invoice No·B/L No·구매처·금액 등을 자동 추출하여
하나의 "서류 대장"으로 관리하는 시스템입니다.

## ⚠️ 시작하기 전에 (보안)

이 레포에는 **실제 키나 비밀번호가 들어있지 않습니다.** 전부 직접 입력하셔야
합니다. `.env`, `*_filled.sql`, `*_ACTUAL.sql` 같은 파일은 `.gitignore`에 의해
절대 이 레포에 올라가지 않습니다 — 본인이 따로 만들어서 본인 PC/Supabase
Secrets에만 보관하세요.

## 전체 구조

```
[ECHO 메일함] (POP3)
      ↓ ① 매일 자동 (export_collector/, 사용자 PC에서 실행)
[Supabase Storage + DB] (files 테이블, status: pending)
      ↓ ② 주기적 자동 (edge_functions/analyze-pending/, Supabase 서버에서 실행)
[Gemini AI 분석] → Invoice No / B/L No / 구매처 / 금액 등 추출
      ↓
[Supabase DB 업데이트] (status: analyzed)
      ↓ ③ 화면에서 확인
[export_tool.html] (브라우저에서 그냥 열면 됨, 별도 설치 불필요)
```

## 폴더 구성

| 경로 | 역할 |
|---|---|
| `export_tool.html` | 메인 화면. 서류 대장 조회, 수동 업로드, 수동 매칭/리네임 |
| `supabase_schema.sql` | Supabase DB 테이블 생성 SQL (최초 1회) |
| `edge_functions/analyze-pending/` | Gemini 분석을 수행하는 Supabase Edge Function |
| `edge_functions/*.sql` | RLS 정책, 자동 스케줄 등록용 SQL |
| `export_collector/` | 메일 자동 수집 스크립트 (Python, Windows 작업 스케줄러로 실행) |

## 설치 순서

1. `supabase_schema.sql` 실행 → DB 테이블 생성
2. Storage에 `export-docs` 버킷 생성 (비공개)
3. `edge_functions/*.sql`로 RLS 정책 적용
4. `edge_functions/analyze-pending/`를 Supabase CLI로 배포
5. `edge_functions/schedule_analysis.sql`로 자동 분석 주기 등록
6. `export_collector/`의 `.env.template`을 `.env`로 복사하고 본인 정보로 채운 뒤,
   Windows 작업 스케줄러에 등록
7. `export_tool.html`을 브라우저로 열고, "파싱 기준" 페이지에서 Supabase
   연결 정보와 Gemini API 키를 입력

각 단계의 자세한 설명은 `edge_functions/DEPLOY_GUIDE.md`와
`export_collector/README.md`를 참고하세요.

## 회사별로 다르게 설정해야 하는 부분

- `export_tool.html`의 시스템 프롬프트(Invoice No 접두사 "OT-MA-", B/L No 접두사
  "NNRK/SSEL/SEL/55014" 등)는 한 회사의 실제 업무 규칙에 맞춰져 있습니다.
  다른 회사에서 쓰려면 이 부분을 본인 회사 규칙으로 바꿔야 합니다.
- `export_collector/collect_mail.py`의 `FORWARDER_DOMAINS`, `CUSTOMS_BROKER_EMAIL`,
  `SUBJECT_KEYWORDS`도 마찬가지로 본인 회사의 거래처/메일 패턴으로 바꿔야 합니다.
