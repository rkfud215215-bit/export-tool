@echo off
REM Export document auto-collector launcher
REM This file is run daily by Windows Task Scheduler.

cd /d "%~dp0"
python collect_mail.py

echo.
echo ============================================
echo Done. Check collector_log.txt for details.
echo Press any key to close this window.
echo ============================================
pause
