-- ============================================================
-- RLS(Row Level Security) 정책 수정
-- 로컬 PC의 자동 수집 스크립트가 publishable(anon) 키로
-- files 테이블에 새 행을 추가하고, Storage에 파일을 업로드할 수 있도록 허용합니다.
--
-- Supabase 대시보드 → SQL Editor → New query 에 아래 내용을 붙여넣고 Run 하세요.
-- ============================================================

-- 1. files 테이블에 INSERT 허용 (anon, authenticated 모두)
create policy "allow insert for collector script"
  on files
  for insert
  to anon, authenticated
  with check (true);

-- 2. files 테이블 SELECT(조회)도 허용 — 나중에 export_tool.html이 화면에 표시할 때 필요
create policy "allow select for collector script"
  on files
  for select
  to anon, authenticated
  using (true);

-- 3. records, record_files 테이블도 나중에 화면에서 읽어야 하므로 SELECT 허용
create policy "allow select on records"
  on records
  for select
  to anon, authenticated
  using (true);

create policy "allow select on record_files"
  on record_files
  for select
  to anon, authenticated
  using (true);

-- ============================================================
-- 4. Storage 버킷(export-docs)에도 업로드 허용 정책 추가
--    Storage는 별도의 storage.objects 테이블에 RLS가 걸려있어 따로 설정해야 합니다.
-- ============================================================
create policy "allow upload to export-docs bucket"
  on storage.objects
  for insert
  to anon, authenticated
  with check (bucket_id = 'export-docs');

create policy "allow read from export-docs bucket"
  on storage.objects
  for select
  to anon, authenticated
  using (bucket_id = 'export-docs');
