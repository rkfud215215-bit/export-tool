# -*- coding: utf-8 -*-
"""
수출 서류 자동 수집기
======================
ECHO 메일(POP3)에서 받은편지함을 확인하여, 수출 관련 메일(포워더가 보낸
B/L·운임청구서, 관세사가 보낸 수출면장 관련 메일)만 골라내고, 그 메일의
PDF 첨부파일을 Supabase Storage에 업로드 + DB(files 테이블)에 기록합니다.

★★★ 중요: 이 스크립트는 메일을 절대 삭제하지 않습니다 ★★★
POP3 RETR(읽기) 명령만 사용하고, DELE(삭제) 명령은 절대 호출하지 않습니다.
따라서 ECHO 서버의 메일은 그대로 남아있고, 평소 쓰는 아웃룩에서도
전혀 영향을 받지 않습니다.

같은 메일을 중복으로 수집하지 않도록, 한 번 처리한 메일의 Message-ID를
processed_ids.txt 파일에 기록해두고, 다음 실행 시 그 목록과 비교합니다.
"""

import os
import re
import sys
import poplib
import email
from email.header import decode_header
import hashlib
import json
from datetime import datetime, timezone

import requests

# ============================================================
# Windows 콘솔(cmd)은 기본 코드페이지가 CP949/CP65001 등으로 설정되어
# 있어, UTF-8로 작성된 한글을 print()할 때 깨지거나 오류가 날 수 있다.
# 이를 방지하기 위해 표준출력/표준에러를 UTF-8로 강제 재설정한다.
# (Python 3.7+ 에서 지원되는 reconfigure 사용, 실패해도 무시하고 진행)
# ============================================================
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding='utf-8')
    except Exception:
        pass


# ============================================================
# 0. 환경설정 읽기 (.env 파일)
# ============================================================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ENV_PATH = os.path.join(SCRIPT_DIR, '.env')
LOG_PATH = os.path.join(SCRIPT_DIR, 'collector_log.txt')
PROCESSED_IDS_PATH = os.path.join(SCRIPT_DIR, 'processed_ids.txt')


def load_env(path):
    """간단한 .env 파일 파서 (KEY=VALUE 형식, # 주석 무시)"""
    config = {}
    if not os.path.exists(path):
        raise FileNotFoundError(
            f".env 파일을 찾을 수 없습니다: {path}\n"
            f".env.template 파일을 복사해서 .env로 이름을 바꾸고, "
            f"비밀번호 등을 채워넣어주세요."
        )
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if '=' not in line:
                continue
            key, _, value = line.partition('=')
            config[key.strip()] = value.strip()
    return config


def log(message):
    """화면 출력 + 로그 파일에도 기록 (나중에 뭐가 처리됐는지 확인용)"""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f"[{timestamp}] {message}"
    print(line)
    try:
        with open(LOG_PATH, 'a', encoding='utf-8') as f:
            f.write(line + '\n')
    except Exception:
        pass  # 로그 파일 쓰기 실패는 전체 작업을 막지 않음


# ============================================================
# 1. 수출 관련 메일 판별 기준
#    (export_tool.html에서 정한 기준과 동일하게 유지)
# ============================================================
FORWARDER_DOMAINS = [
    'kwe.com',          # KINTETSU WORLD EXPRESS
    'nnrkorea.co.kr',   # NNR GLOBAL LOGISTICS
    'scangl.com',       # SCAN GLOBAL LOGISTICS
    'dsv.com',          # DSV AIR & SEA
]
CUSTOMS_BROKER_EMAIL = 'cannyg@nate.com'  # 지평관세법인
SUBJECT_KEYWORDS = ['수출 면장 요청', '수출면장 요청']


def decode_mime_words(s):
    """메일 제목/발신자 등에 흔한 MIME 인코딩(=?UTF-8?B?...?=) 디코딩"""
    if not s:
        return ''
    decoded_parts = decode_header(s)
    result = ''
    for part, encoding in decoded_parts:
        if isinstance(part, bytes):
            try:
                result += part.decode(encoding or 'utf-8', errors='replace')
            except (LookupError, TypeError):
                result += part.decode('utf-8', errors='replace')
        else:
            result += part
    return result


def extract_email_address(raw_from):
    """'홍길동 <hong@example.com>' 형태에서 이메일 주소만 추출"""
    m = re.search(r'[\w\.\-+]+@[\w\.\-]+', raw_from or '')
    return m.group(0).lower() if m else ''


def is_export_related(from_addr, subject, to_addrs, cc_addrs):
    """
    수출 관련 메일인지 판별.
    1순위: 보낸사람이 포워더 도메인 또는 관세사 이메일
    2순위: 제목에 '수출 면장 요청' 포함
    3순위: 수신자 목록(To/Cc)에 관세사 이메일이 포함
    """
    from_domain = from_addr.split('@')[-1] if '@' in from_addr else ''

    if any(from_domain.endswith(d) for d in FORWARDER_DOMAINS):
        return True, f'포워더 도메인({from_domain})'

    if from_addr == CUSTOMS_BROKER_EMAIL:
        return True, '관세사 발신'

    if any(kw in (subject or '') for kw in SUBJECT_KEYWORDS):
        return True, '제목에 수출면장 요청 키워드 포함'

    all_recipients = (to_addrs or []) + (cc_addrs or [])
    if CUSTOMS_BROKER_EMAIL in all_recipients:
        return True, '관세사가 수신자(참조 포함)에 있음'

    return False, ''


# ============================================================
# 2. POP3로 메일 가져오기 (절대 삭제하지 않음)
# ============================================================
def fetch_mails(host, port, user, password):
    """
    POP3로 접속해서 받은편지함의 모든 메일을 가져온다.
    RETR(읽기)만 사용하고 DELE(삭제)는 절대 호출하지 않으므로
    서버의 메일은 그대로 보존된다.
    반환값: [(message_id, email.message.Message 객체), ...]
    """
    log(f'POP3 서버에 연결 시도 중... ({host}:{port})')
    try:
        conn = poplib.POP3(host, port, timeout=30)
    except Exception as e:
        raise Exception(
            f'서버 연결 자체가 실패했습니다 (네트워크/방화벽/보안프로그램 미로그인 가능성): {e}'
        )
    log('서버 연결 성공. 로그인 시도 중...')

    try:
        try:
            conn.user(user)
            conn.pass_(password)
        except poplib.error_proto as e:
            raise Exception(f'로그인 실패 (사용자명 또는 비밀번호가 틀렸을 가능성): {e}')

        log('로그인 성공.')
        count, _ = conn.stat()
        log(f'받은편지함 메일 개수: {count}건')
        log(f'메일을 하나씩 내려받는 중입니다... (총 {count}건, 시간이 걸릴 수 있습니다)')

        mails = []
        for i in range(1, count + 1):
            if i == 1 or i % 10 == 0 or i == count:
                log(f'  진행 중... {i}/{count}건')
            try:
                _, lines, _ = conn.retr(i)  # RETR만 사용, DELE 호출 안 함
                raw_email = b'\r\n'.join(lines)
                msg = email.message_from_bytes(raw_email)
                message_id = msg.get('Message-ID', '').strip()
                if not message_id:
                    # Message-ID가 없는 메일은 내용 해시로 대체 식별자 생성
                    message_id = 'hash:' + hashlib.md5(raw_email).hexdigest()
                mails.append((message_id, msg))
            except Exception as e:
                log(f'  ⚠ {i}번째 메일 읽기 실패 (건너뜀): {e}')
        return mails
    finally:
        # quit()은 RETR한 메일을 삭제하지 않음 (DELE을 호출한 적 없으므로 안전)
        try:
            conn.quit()
        except Exception:
            pass


# ============================================================
# 3. 첨부파일(PDF) 추출
# ============================================================
def extract_pdf_attachments(msg):
    """메일에서 PDF 첨부파일만 추출. 반환: [(filename, bytes), ...]"""
    attachments = []
    for part in msg.walk():
        content_disposition = str(part.get('Content-Disposition') or '')
        if 'attachment' not in content_disposition.lower():
            continue
        filename = part.get_filename()
        if not filename:
            continue
        filename = decode_mime_words(filename)
        if not filename.lower().endswith('.pdf'):
            continue
        payload = part.get_payload(decode=True)
        if payload:
            attachments.append((filename, payload))
    return attachments


# ============================================================
# 4. Supabase 업로드
# ============================================================
def upload_to_supabase(supabase_url, supabase_key, filename, file_bytes,
                        mail_subject, mail_from, mail_message_id, mail_date):
    """
    Storage(export-docs 버킷)에 파일 업로드 + files 테이블에 메타데이터 기록.

    ★ Storage 경로(key)는 한글/특수문자가 들어가면 Supabase가 "Invalid key"로
       거부하는 경우가 있어, 경로 자체는 해시값 기반으로 영문/숫자만 사용한다.
       원본 한글 파일명은 절대 잃어버리지 않고 DB의 original_name 컬럼에
       그대로 보존해서, 나중에 화면에 표시하거나 리네임할 때 그 값을 쓴다.
    """
    file_hash = hashlib.md5(file_bytes).hexdigest()
    ext = os.path.splitext(filename)[1].lower() or '.pdf'
    today_folder = datetime.now().strftime('%Y-%m-%d')
    # 경로는 순수 영문/숫자/하이픈/슬래시로만 구성 (한글, 공백, 특수문자 전부 제외)
    storage_path = f'raw/{today_folder}/{file_hash}{ext}'

    headers_storage = {
        'Authorization': f'Bearer {supabase_key}',
        'apikey': supabase_key,
        'Content-Type': 'application/pdf',
    }
    storage_api = f'{supabase_url}/storage/v1/object/export-docs/{storage_path}'
    res = requests.post(storage_api, headers=headers_storage, data=file_bytes, timeout=60)

    # ★ 409 Duplicate: storage_path가 파일 내용의 해시값 기반이라, 완전히 같은
    #    내용의 PDF가 여러 메일(원본+답장 등)에 중복 첨부된 경우 "이미 업로드됨"으로
    #    뜬다. 이건 오류가 아니라 정상적인 중복 방지 동작이므로 그대로 진행한다.
    is_duplicate = (res.status_code == 409)
    if res.status_code not in (200, 201) and not is_duplicate:
        raise Exception(f'Storage 업로드 실패 (HTTP {res.status_code}): {res.text[:300]}')

    # files 테이블에 메타데이터 insert
    headers_db = {
        'Authorization': f'Bearer {supabase_key}',
        'apikey': supabase_key,
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal',
    }
    row = {
        'storage_path': storage_path,
        'original_name': filename,
        'file_hash': file_hash,
        'file_size_bytes': len(file_bytes),
        'mime_type': 'application/pdf',
        'source_type': 'email',
        'mail_message_id': mail_message_id,
        'mail_subject': mail_subject,
        'mail_received_at': mail_date,
        'status': 'pending',
    }
    db_api = f'{supabase_url}/rest/v1/files'
    res2 = requests.post(db_api, headers=headers_db, json=row, timeout=30)

    # DB에도 (mail_message_id + original_name) 유니크 제약이 있어, 같은 메일을
    # 재시도하다 일부만 성공했던 경우 등에서 중복 insert가 시도될 수 있다.
    # 이 역시 오류가 아니라 정상적인 중복 방지 동작이므로 그대로 진행한다.
    if res2.status_code == 409:
        is_duplicate = True
    elif res2.status_code not in (200, 201):
        raise Exception(f'DB 기록 실패 (HTTP {res2.status_code}): {res2.text[:300]}')

    return storage_path, is_duplicate


# ============================================================
# 5. 중복 처리 방지 (이미 처리한 메일 ID 기록/조회)
# ============================================================
def load_processed_ids():
    if not os.path.exists(PROCESSED_IDS_PATH):
        return set()
    with open(PROCESSED_IDS_PATH, 'r', encoding='utf-8') as f:
        return set(line.strip() for line in f if line.strip())


def mark_as_processed(message_id):
    with open(PROCESSED_IDS_PATH, 'a', encoding='utf-8') as f:
        f.write(message_id + '\n')


# ============================================================
# 6. 메인 실행
# ============================================================
def main():
    log('=' * 60)
    log('수출 서류 자동 수집 시작')

    try:
        config = load_env(ENV_PATH)
    except FileNotFoundError as e:
        log(f'❌ 오류: {e}')
        return

    required_keys = ['ECHO_POP3_HOST', 'ECHO_POP3_PORT', 'ECHO_POP3_USER',
                      'ECHO_POP3_PASSWORD', 'SUPABASE_URL', 'SUPABASE_KEY']
    missing = [k for k in required_keys if not config.get(k)]
    if missing:
        log(f'❌ .env 파일에 다음 항목이 비어있습니다: {", ".join(missing)}')
        return

    processed_ids = load_processed_ids()
    log(f'기존에 처리한 메일: {len(processed_ids)}건')

    try:
        mails = fetch_mails(
            config['ECHO_POP3_HOST'],
            int(config['ECHO_POP3_PORT']),
            config['ECHO_POP3_USER'],
            config['ECHO_POP3_PASSWORD'],
        )
    except Exception as e:
        log(f'❌ POP3 접속/메일 가져오기 실패: {e}')
        log('   (ECHO 서버 접속이 보안프로그램 로그인 상태에서만 허용되는 경우, '
            '먼저 보안프로그램에 로그인되어 있는지 확인해주세요.)')
        return

    new_count = 0
    skipped_count = 0
    irrelevant_count = 0
    error_count = 0
    uploaded_files_count = 0

    for message_id, msg in mails:
        if message_id in processed_ids:
            skipped_count += 1
            continue  # 이미 처리한 메일

        subject = decode_mime_words(msg.get('Subject', ''))
        from_raw = decode_mime_words(msg.get('From', ''))
        from_addr = extract_email_address(from_raw)
        to_addrs = [extract_email_address(a) for a in (msg.get('To') or '').split(',')]
        cc_addrs = [extract_email_address(a) for a in (msg.get('Cc') or '').split(',')]
        mail_date_raw = msg.get('Date', '')

        relevant, reason = is_export_related(from_addr, subject, to_addrs, cc_addrs)

        if not relevant:
            irrelevant_count += 1
            mark_as_processed(message_id)  # 무관한 메일도 다시 안 보게 기록
            continue

        log(f'✔ 수출 관련 메일 발견: "{subject}" (보낸사람: {from_addr}, 판별: {reason})')

        attachments = extract_pdf_attachments(msg)
        if not attachments:
            log(f'   ⚠ PDF 첨부파일 없음 — 건너뜀')
            mark_as_processed(message_id)
            continue

        try:
            mail_date_iso = email.utils.parsedate_to_datetime(mail_date_raw).isoformat() \
                if mail_date_raw else None
        except Exception:
            mail_date_iso = None

        all_ok = True
        for filename, file_bytes in attachments:
            try:
                path, is_dup = upload_to_supabase(
                    config['SUPABASE_URL'], config['SUPABASE_KEY'],
                    filename, file_bytes, subject, from_addr, message_id, mail_date_iso,
                )
                if is_dup:
                    log(f'   ↺ 동일 내용 파일 이미 존재 (정상, 건너뜀): {filename} -> {path}')
                else:
                    log(f'   ⬆ 업로드 완료: {filename} -> {path}')
                uploaded_files_count += 1
            except Exception as e:
                log(f'   ❌ 업로드 실패 ({filename}): {e}')
                all_ok = False
                error_count += 1

        if all_ok:
            new_count += 1
            mark_as_processed(message_id)
        # 업로드 실패 시 processed_ids에 기록하지 않음 → 다음 실행 때 재시도됨

    log('-' * 60)
    log(f'처리 완료. 새로 처리한 수출 메일: {new_count}건, '
        f'업로드된 파일: {uploaded_files_count}개, '
        f'무관한 메일: {irrelevant_count}건, '
        f'이미 처리됨(스킵): {skipped_count}건, '
        f'오류: {error_count}건')
    log('=' * 60)


if __name__ == '__main__':
    main()
