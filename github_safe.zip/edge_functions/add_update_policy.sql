-- ============================================================
-- files 테이블에 UPDATE 권한 추가
-- export_tool.html에서 "서류 종류 수동 지정" 기능을 쓸 때, 그 변경 내용을
-- DB에도 저장하기 위해 필요합니다. SQL Editor → New query에 붙여넣고 Run.
-- ============================================================
create policy "allow update for manual doc type change"
  on files
  for update
  to anon, authenticated
  using (true)
  with check (true);
