// ============================================================
// Supabase Edge Function: analyze-pending
// ============================================================
// files 테이블에서 status='pending'인 행을 찾아, Storage에서 PDF를
// 가져와 Gemini Vision(PDF 직접 입력)으로 분석한 뒤, 그 결과를 같은
// files 행에 저장하고 status를 'analyzed'로 바꾼다.
//
// export_tool.html의 GEMINI_SYSTEM_PROMPT, BL No/구매처/금액 보강
// 정규식 로직을 그대로 가져와 동일한 분류 기준을 적용한다.
//
// 호출 방식: 외부 스케줄러(pg_cron 또는 cron-job.org 등)가 이 함수를
// 주기적으로(예: 10분마다) HTTP POST로 호출한다. 사람이 직접 누를
// 필요 없이 자동으로 돌아간다.
// ============================================================

import { createClient } from 'jsr:@supabase/supabase-js@2';

// ────────────────────────────────────────────
// 환경변수 (Supabase Edge Function Secrets에 등록되어 있어야 함)
// ────────────────────────────────────────────
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY')!;

// 한 번 호출에서 동시에 처리할 최대 파일 개수
// (너무 크게 잡으면 Edge Function 시간 제한을 넘기거나, 요청 실패 시
//  되돌려야 하는 양이 커진다. 호출 주기를 2분으로 줄인 것과 맞춰 15로 조정)
const BATCH_SIZE = 15;

// ────────────────────────────────────────────
// Gemini 모델 자동 탐색 (export_tool.html과 동일한 정책)
// ────────────────────────────────────────────
const GEMINI_MODEL_CANDIDATES_FALLBACK = [
  'gemini-flash-latest',
  'gemini-2.5-flash',
  'gemini-2.5-flash-lite',
  'gemini-3-flash',
  'gemini-1.5-flash',
  'gemini-pro-latest',
];

async function fetchAvailableGeminiModels(): Promise<string[]> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${GEMINI_API_KEY}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`모델 목록 조회 실패 (HTTP ${res.status})`);
  const data = await res.json();
  const models = (data.models || [])
    .filter((m: any) => Array.isArray(m.supportedGenerationMethods) &&
                         m.supportedGenerationMethods.includes('generateContent'))
    .map((m: any) => (m.name || '').replace(/^models\//, ''))
    .filter(Boolean);
  const flashFirst = models.filter((n: string) => /flash/i.test(n));
  const others = models.filter((n: string) => !/flash/i.test(n));
  return [...flashFirst, ...others];
}

async function callGeminiOnce(modelName: string, parts: any[]): Promise<any> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${GEMINI_API_KEY}`;
  const body = {
    contents: [{ role: 'user', parts }],
    generationConfig: { temperature: 0, responseMimeType: 'application/json' },
  };
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    let errText = '';
    try { errText = (await res.json())?.error?.message || ''; } catch (_) { /* ignore */ }
    const err: any = new Error(`Gemini API HTTP ${res.status} 오류` + (errText ? `: ${errText}` : ''));
    err.httpStatus = res.status;
    throw err;
  }
  return await res.json();
}

let cachedModel: string | null = null;
const blockedModels = new Set<string>();

async function callGeminiWithFallback(parts: any[]): Promise<any> {
  if (cachedModel && !blockedModels.has(cachedModel)) {
    try {
      return await callGeminiOnce(cachedModel, parts);
    } catch (e: any) {
      if (e.httpStatus === 429) {
        blockedModels.add(cachedModel);
        cachedModel = null;
      } else {
        throw e;
      }
    }
  }

  let candidates: string[];
  try {
    candidates = await fetchAvailableGeminiModels();
    if (!candidates.length) candidates = GEMINI_MODEL_CANDIDATES_FALLBACK;
  } catch (_) {
    candidates = GEMINI_MODEL_CANDIDATES_FALLBACK;
  }

  let lastErr: any = null;
  for (const model of candidates) {
    if (blockedModels.has(model)) continue;
    try {
      const data = await callGeminiOnce(model, parts);
      cachedModel = model;
      console.info('[Gemini] 사용 모델 확정:', model);
      return data;
    } catch (e: any) {
      lastErr = e;
      if (e.httpStatus === 404 || e.httpStatus === 429) {
        if (e.httpStatus === 429) blockedModels.add(model);
        continue;
      }
      throw e;
    }
  }
  throw new Error(`사용 가능한 Gemini 모델을 찾지 못했습니다. 마지막 오류: ${lastErr?.message || '알 수 없음'}`);
}

// ────────────────────────────────────────────
// 시스템 프롬프트 (export_tool.html과 완전히 동일하게 유지)
// ────────────────────────────────────────────
const GEMINI_SYSTEM_PROMPT = `너는 수출 서류(인보이스, B/L, 수출신고필증, 포워더 운임청구서) 분석 전문가다.
여러 개의 서류 이미지/텍스트가 [FILE #n: 파일명] 마커로 구분되어 입력된다.
각 파일에 대해 아래 JSON 스키마에 맞춰 정보를 추출하고, 파일 입력 순서와 동일한 순서의 JSON 배열로만 응답해라.
설명, 마크다운 코드블록(\`\`\`json 등), 그 외 텍스트는 절대 포함하지 말고 순수 JSON 배열만 출력해라.

각 파일 객체 스키마:
{
  "fileIndex": 0,
  "docType": "INVOICE" | "BL" | "EXPORT" | "FORWARDER_INVOICE" | "PACKING_LIST" | "OTHER" | "UNKNOWN",
  "invoiceNo": "",
  "blNo": "",
  "exportNo": "",
  "declDate": "",
  "buyer": "",
  "currency": "",
  "amount": "",
  "etd": "",
  "forwarder": ""
}

★★★★★ docType 판별 규칙 (모든 것보다 최우선, 반드시 가장 먼저 적용) ★★★★★
docType은 추측하지 말고, 문서에 실제로 적힌 제목/양식 명칭을 기준으로 기계적으로 판별해라.
어떤 문서든 "Invoice No(OT-MA-) 같은 번호가 안에 보인다"는 이유만으로 INVOICE로 분류하면 절대 안 된다.
번호는 여러 문서에 공통으로 적힐 수 있는 참조값일 뿐, 문서 종류를 결정하는 기준이 아니다.

판별 순서 (위에서부터 확인해서 먼저 맞는 것으로 결정, 하나라도 해당하면 즉시 그 타입으로 확정하고 더 따지지 않음):

1. 문서 상단에 "수출신고필증", "수출신고필증(적재전", "수출면장", "수출신고번호", 또는 한국 관세청
   로고/UNI-PASS 마크가 보이면 → 무조건 EXPORT. (안에 OT-MA- 번호나 Invoice 비슷한 단어가
   같이 보여도 무조건 EXPORT다. 한국어 관공서 서류 양식이면 절대 INVOICE가 아니다.)

2. 문서 상단에 "BILL OF LADING", "MULTIMODAL TRANSPORT BILL", "AIR WAYBILL", "AIRWAYBILL",
   "Not Negotiable" + 화물 정보(SHIPPER/CONSIGNEE/항공사) 양식이 보이면 → 무조건 BL.

3. 문서 상단에 "운임청구서", "FREIGHT INVOICE", "청구서", "DEBIT NOTE", 또는 포워더 회사
   (KWE/NNR/DSV/SCAN 등)가 발행한 요금 청구 양식이면 → 무조건 FORWARDER_INVOICE.

4. 문서 상단에 "PACKING LIST"라는 제목이 있으면 → 무조건 PACKING_LIST.
   (Invoice와 비슷하게 SHIPPER/CONSIGNEE가 있어도, 제목이 PACKING LIST면 PACKING_LIST다.
   포장 단위, 박스 수, 중량(N.W./G.W.) 표 위주 양식이면 더 확실하다.)

5. 그 외, "COMMERCIAL INVOICE" 제목이거나, 수출자(HANSOL ORIONTECH 등)가 작성한
   상업송장 양식(SHIPPER/CONSIGNEE + 품목/단가/수량 표 + INVOICE NO 라벨)이면 → INVOICE.

6. "MSDS", "Material Safety Data Sheet", "물질안전보건자료", 제품 인증서, 시험성적서,
   원산지증명서 등 위 5가지(EXPORT/BL/FORWARDER_INVOICE/PACKING_LIST/INVOICE)에 전혀
   해당하지 않는 참고/첨부 자료라면 → OTHER. (이런 문서는 추측해서 다른 타입에 억지로
   끼워맞추지 말고 OTHER로 분류해라.)

7. 위 어디에도 해당하지 않거나 문서가 손상되어 판단이 불가능하면 → UNKNOWN.

★★★ invoiceNo 관련 절대 규칙 (가장 중요, 반드시 지켜라) ★★★
- invoiceNo는 오직 "우리 회사(수출자, HANSOL ORIONTECH 등)가 발급한 Invoice"의 번호이며,
  형식은 거의 항상 "OT-MA-XXXXXX" 패턴이다.
- 문서 안에 "OT-MA-"로 시작하는 값이 보이지 않으면, invoiceNo는 반드시 빈 문자열("")로 두어라.
- 포워더청구서(FORWARDER_INVOICE)나 NNR/KWE/DSV/SCAN 같은 포워더가 발행한 문서에는
  "DOCUMENT NO", "INV.NO", "REF NO", "AWB NO" 같은 라벨로 그 포워더 자체의 청구서/관리번호가
  적혀 있는데, 이런 번호들은 절대로 invoiceNo가 아니다. "OT-MA-" 패턴이 아니면 그 어떤 번호도
  invoiceNo에 넣지 마라.
- 수출신고필증(EXPORT)에도 "송품장부호" 필드에 OT-MA- 번호가 적혀있는 경우가 흔하다.
  이건 그 면장이 어떤 Invoice 건에 대한 면장인지 참조하는 값일 뿐이며, 그 번호가 보인다고
  해서 그 문서가 INVOICE 타입이 되는 게 아니다. docType은 위 1번 규칙을 그대로 따른다.

기타 규칙:
- B/L No는 반드시 NNRK, SSEL, SEL, 55014 로 시작하는 값만 인정한다. 그 외는 절대 넣지 마라.
- 포워더청구서(FORWARDER_INVOICE)에서 B/L No는 "HWB NO", "B/L NO", "AWB NO", "MAWB NO" 같은
  레이블 옆에 있는 값들 중에서 NNRK/SSEL/SEL/55014로 시작하는 값을 찾아라.
- 구매처(buyer)는 수출신고필증(EXPORT)에서만 추출하고, 그 외 문서타입에서는 항상 빈 문자열로 둔다.
- 금액(currency, amount)도 수출신고필증(EXPORT)에서만 추출하고 그 외에는 빈 문자열로 둔다.
- 값이 명확하지 않으면 추측하지 말고 빈 문자열로 두어라.`;

// ────────────────────────────────────────────
// 보강 검증용 정규식 함수들 (export_tool.html과 동일)
// ────────────────────────────────────────────
function compact(s: string) { return (s || '').toUpperCase().replace(/\s+/g, ''); }
function normBL(s: string) { return (s || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); }

const BL_PREFIXES = ['NNRK', 'SSEL', 'SEL', '55014'];
const BL_PREFIX_FORWARDER: Record<string, string> = {
  NNRK: 'NNR GLOBAL LOGISTICS',
  SSEL: 'SCAN GLOBAL LOGISTICS',
  SEL: 'DSV AIR & SEA',
  '55014': 'KINTETSU WORLD EXPRESS',
};

function extractBLNo(text: string): string {
  const sorted = [...BL_PREFIXES].sort((a, b) => b.length - a.length);
  const tC = compact(text);
  for (const p of sorted) {
    const esc = p.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    let m = text.match(new RegExp('(?<![A-Z0-9])(' + esc + ')[\\s\\-]*([A-Z0-9]{4,20})(?![A-Z0-9])', 'i'));
    if (m) return (m[1].replace(/[\s\-]+$/, '') + m[2]).toUpperCase();
    m = tC.match(new RegExp('(?<![A-Z0-9])(' + esc + ')([A-Z0-9]{4,20})(?![A-Z0-9])', 'i'));
    if (m) return (m[1].replace(/[\s\-]+$/, '') + m[2]).toUpperCase();
  }
  return '';
}

function inferForwarderFromBL(blNo: string): string {
  if (!blNo) return '';
  const n = blNo.toUpperCase();
  if (n.startsWith('NNRK')) return BL_PREFIX_FORWARDER.NNRK;
  if (n.startsWith('SSEL')) return BL_PREFIX_FORWARDER.SSEL;
  if (n.startsWith('SEL')) return BL_PREFIX_FORWARDER.SEL;
  if (n.startsWith('55014')) return BL_PREFIX_FORWARDER['55014'];
  return '';
}

function extractExportInvoiceNo(text: string): string {
  const m = text.match(/송품장부호[:\s]*([A-Z0-9\-]{4,30})/i);
  return m && m[1] ? m[1].trim().toUpperCase() : '';
}

function extractExportNo(text: string): string {
  const ps = [/수출신고번호[:\s]*([0-9\-]{6,}[0-9A-Z])/, /\b(\d{5}-\d{2}-\d{6}[A-Z0-9])\b/];
  for (const p of ps) { const m = text.match(p); if (m && m[1]) return m[1].trim(); }
  return '';
}

function extractDeclDate(text: string): string {
  let m = text.match(/신고일자[:\s]*([0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2})/);
  if (m && m[1]) return m[1].replace(/\//g, '-').trim();
  m = text.match(/\d{5}-\d{2}-\d{6}[A-Z0-9]\s+\S+\s+([0-9]{4}-[0-9]{2}-[0-9]{2})/);
  if (m && m[1]) return m[1].trim();
  return '';
}

function extractBuyer(text: string, docType: string): string {
  if (docType !== 'EXPORT') return '';
  let m = text.match(/[\u2463④4]?\s*구\s*매\s*자\s*[:\s]*([^\n\r\u2464\u2465\u2466\u2467\u2468\u2469]{2,60})/);
  if (m && m[1]) {
    const v = m[1].split(/\(구매자부호\)|결제금액|선적항|통관세관|목적국|환급신청인/)[0].replace(/\s+/g, ' ').trim();
    if (v.length >= 2 && !v.includes('환급') && !v.includes('신청인')) return v.substring(0, 40);
  }
  const p2 = /구\s*매\s*자\s*[:\s]*([^\n\r\u2464\u2465\u2466\u2467\u2468\u2469]{2,60})/gi;
  let p2m;
  while ((p2m = p2.exec(text)) !== null) {
    const v2 = p2m[1].split(/\(구매자부호\)|결제금액|선적항|통관세관|목적국|환급신청인/)[0].replace(/\s+/g, ' ').trim();
    if (v2.length >= 2 && !v2.includes('환급') && !v2.includes('신청인') && !/한솔|HANSOL/i.test(v2)) {
      return v2.substring(0, 40);
    }
  }
  return '';
}

function extractCurrencyAmount(text: string, docType: string): { currency: string; amount: string } {
  if (docType !== 'EXPORT') return { currency: '', amount: '' };
  const codes = 'USD EUR JPY GBP CNY AUD CAD SGD HKD KRW'.split(/\s+/).join('|');
  const p1 = new RegExp('(?:FOB|CIF|CFR|EXW)-?(' + codes + ')-([0-9]{1,3}(?:,[0-9]{3})*(?:\\.[0-9]{1,2})?)', 'i');
  let m = text.match(p1);
  if (m) return { currency: m[1].toUpperCase(), amount: m[2] };
  const p2 = new RegExp('결제금액[^\\n]*(' + codes + ')[^\\d]*([0-9]{1,3}(?:,[0-9]{3})*(?:\\.[0-9]{1,2})?)', 'i');
  m = text.match(p2);
  if (m) return { currency: m[1].toUpperCase(), amount: m[2] };
  return { currency: '', amount: '' };
}

const INV_PREFIX = 'OT-MA-';

// ────────────────────────────────────────────
// PDF에서 텍스트 레이어 추출 (보강 검증용)
// Deno 환경에는 pdf.js의 canvas 렌더링이 없으므로, 매우 간단한
// PDF 텍스트 스트림 추출만 시도한다 (완벽하지 않아도 보강 용도로는 충분).
// 실패하면 빈 문자열을 반환하고 Gemini 응답만으로 진행한다.
// ────────────────────────────────────────────
async function extractPdfRawText(pdfBytes: Uint8Array): Promise<string> {
  try {
    // PDF 내부의 텍스트 스트림은 보통 (...) Tj 또는 [...] TJ 형태로 들어있다.
    // 완벽한 파서는 아니지만, 한국 수출신고필증처럼 텍스트 기반 PDF에서는
    // 꽤 많은 텍스트를 건질 수 있어 보강 검증 용도로 충분하다.
    const decoder = new TextDecoder('latin1');
    const raw = decoder.decode(pdfBytes);
    const matches = raw.match(/\(((?:[^()\\]|\\.)*)\)\s*Tj/g) || [];
    const texts = matches.map((m) => {
      const inner = m.match(/\(((?:[^()\\]|\\.)*)\)/);
      return inner ? inner[1].replace(/\\(.)/g, '$1') : '';
    });
    return texts.join(' ');
  } catch (_) {
    return '';
  }
}

// ────────────────────────────────────────────
// 메인 핸들러
// ────────────────────────────────────────────
Deno.serve(async (req: Request) => {
  if (req.method !== 'POST' && req.method !== 'GET') {
    return new Response('Method Not Allowed', { status: 405 });
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

  // 1) status='pending'인 파일을 최대 BATCH_SIZE개 가져옴
  const { data: pendingFiles, error: fetchErr } = await supabase
    .from('files')
    .select('*')
    .eq('status', 'pending')
    .order('created_at', { ascending: true })
    .limit(BATCH_SIZE);

  if (fetchErr) {
    return new Response(JSON.stringify({ error: fetchErr.message }), { status: 500 });
  }

  if (!pendingFiles || pendingFiles.length === 0) {
    return new Response(JSON.stringify({ message: '분석할 새 파일이 없습니다.', processed: 0 }), {
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // 2) 각 파일을 Storage에서 다운로드 + base64 인코딩 + 텍스트 보강용 추출
  const fileBundles: Array<{ id: string; name: string; base64: string; rawText: string }> = [];

  for (const f of pendingFiles) {
    try {
      const { data: blob, error: dlErr } = await supabase.storage
        .from('export-docs')
        .download(f.storage_path);
      if (dlErr || !blob) throw new Error(dlErr?.message || '다운로드 실패');

      const arrayBuffer = await blob.arrayBuffer();
      const bytes = new Uint8Array(arrayBuffer);
      const base64 = btoa(Array.from(bytes, (b) => String.fromCharCode(b)).join(''));
      const rawText = await extractPdfRawText(bytes);

      fileBundles.push({ id: f.id, name: f.original_name, base64, rawText });
    } catch (e: any) {
      // 다운로드 자체가 실패하면 그 파일만 에러 상태로 표시하고 나머지는 계속 진행
      await supabase.from('files').update({
        status: 'error',
        error_message: `다운로드 실패: ${e.message}`,
      }).eq('id', f.id);
    }
  }

  if (fileBundles.length === 0) {
    return new Response(JSON.stringify({ message: '다운로드 가능한 파일이 없습니다.', processed: 0 }), {
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // 3) Gemini에 한 번에 분석 요청 (PDF 직접 입력 방식)
  const parts: any[] = [{ text: GEMINI_SYSTEM_PROMPT }];
  fileBundles.forEach((b, idx) => {
    parts.push({ text: `\n\n[FILE #${idx}: ${b.name}]` });
    parts.push({ inline_data: { mime_type: 'application/pdf', data: b.base64 } });
  });
  parts.push({ text: `\n\n위 ${fileBundles.length}개 파일에 대해 JSON 배열로만 응답해라. 배열 길이는 정확히 ${fileBundles.length}개여야 한다.` });

  let geminiResults: any[] = [];
  try {
    const data = await callGeminiWithFallback(parts);
    let raw = data.candidates?.[0]?.content?.parts?.[0]?.text || '[]';
    raw = raw.replace(/^```json\s*/i, '').replace(/```\s*$/, '').trim();
    geminiResults = JSON.parse(raw);
    if (!Array.isArray(geminiResults)) throw new Error('Gemini 응답이 배열이 아님');
  } catch (e: any) {
    // 전체 배치가 실패하면, 이번 배치 파일들을 다시 pending으로 남겨두고 종료
    // (다음 호출에서 자동으로 재시도됨)
    return new Response(JSON.stringify({ error: `Gemini 분석 실패: ${e.message}`, processed: 0 }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // 4) 결과를 각 파일에 매핑 + 보강 검증 + DB 업데이트
  let successCount = 0;
  let errorCount = 0;

  for (let i = 0; i < fileBundles.length; i++) {
    const fb = fileBundles[i];
    const r = geminiResults.find((x: any) => x.fileIndex === i) || geminiResults[i] || {};

    let docType = r.docType || 'UNKNOWN';

    // EXPORT 강제 교정 (export_tool.html과 동일 정책)
    if (fb.rawText && /수출신고필증|수출면장|수출신고번호|결제금액/.test(fb.rawText)) {
      docType = 'EXPORT';
    } else if (fb.rawText && /BILL OF LADING|MULTIMODAL TRANSPORT BILL|AIR WAYBILL|AIRWAYBILL/i.test(fb.rawText)) {
      docType = 'BL';
    } else if (fb.rawText && /청구서|운임|예금주|은행|DEBIT NOTE|FREIGHT INVOICE/i.test(fb.rawText)) {
      docType = 'FORWARDER_INVOICE';
    }

    const rawInvoiceNo = (r.invoiceNo || '').trim().toUpperCase();
    let invoiceNo = rawInvoiceNo.startsWith(INV_PREFIX) ? rawInvoiceNo : '';

    let blNoRaw = (r.blNo || '').trim().toUpperCase();
    let blNo = /^(NNRK|SSEL|SEL|55014)/.test(blNoRaw) ? blNoRaw : '';
    if (!blNo && fb.rawText) {
      const fromText = extractBLNo(fb.rawText);
      if (fromText) blNo = fromText;
    }

    let exportNo = r.exportNo || '';
    let declDate = r.declDate || '';
    let buyer = docType === 'EXPORT' ? (r.buyer || '') : '';
    let currency = docType === 'EXPORT' ? (r.currency || '') : '';
    let amount = docType === 'EXPORT' ? (r.amount || '') : '';

    if (docType === 'EXPORT' && fb.rawText) {
      const textInv = extractExportInvoiceNo(fb.rawText);
      if (textInv) invoiceNo = textInv;
      const textExpNo = extractExportNo(fb.rawText);
      if (textExpNo) exportNo = textExpNo;
      const textDate = extractDeclDate(fb.rawText);
      if (textDate) declDate = textDate;
      const textBuyer = extractBuyer(fb.rawText, 'EXPORT');
      if (textBuyer) buyer = textBuyer;
      const textCurAmt = extractCurrencyAmount(fb.rawText, 'EXPORT');
      if (textCurAmt.currency) { currency = textCurAmt.currency; amount = textCurAmt.amount; }
    } else if (docType !== 'EXPORT') {
      exportNo = ''; declDate = ''; buyer = ''; currency = ''; amount = '';
    }

    const etd = r.etd || '';
    const forwarder = inferForwarderFromBL(blNo) || r.forwarder || '';

    const { error: updateErr } = await supabase
      .from('files')
      .update({
        status: 'analyzed',
        doc_type: docType,
        invoice_no: invoiceNo || null,
        bl_no: blNo || null,
        export_no: exportNo || null,
        decl_date: declDate || null,
        buyer: buyer || null,
        currency: currency || null,
        amount: amount || null,
        etd: etd || null,
        forwarder: forwarder || null,
        raw_gemini_json: r,
      })
      .eq('id', fb.id);

    if (updateErr) {
      errorCount++;
      await supabase.from('files').update({
        status: 'error',
        error_message: `DB 업데이트 실패: ${updateErr.message}`,
      }).eq('id', fb.id);
    } else {
      successCount++;
    }
  }

  return new Response(
    JSON.stringify({
      message: '분석 완료',
      total: fileBundles.length,
      success: successCount,
      error: errorCount,
    }),
    { headers: { 'Content-Type': 'application/json' } },
  );
});
