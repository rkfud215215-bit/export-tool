-- ============================================================
-- Edge Function 자동 주기 실행 설정 (pg_cron)
-- Supabase 대시보드 → SQL Editor → New query 에 붙여넣고 실행하세요.
--
-- ★ 실행 전에 아래 두 곳을 본인 값으로 바꿔주세요 ★
--   1. <PROJECT_REF> → mplvptnshltlubulxykw
--   2. <SERVICE_ROLE_KEY> → sb_secret_로 시작하는 그 키
-- ============================================================

-- pg_cron, pg_net 확장 활성화 (Supabase는 보통 기본 제공, 안 되어 있으면 활성화)
create extension if not exists pg_cron;
create extension if not exists pg_net;

-- 기존에 같은 이름의 작업이 있으면 제거 (재실행 시 중복 등록 방지)
select cron.unschedule('analyze-pending-files')
where exists (
  select 1 from cron.job where jobname = 'analyze-pending-files'
);

-- 10분마다 analyze-pending Edge Function을 호출하는 작업 등록
select cron.schedule(
  'analyze-pending-files',           -- 작업 이름
  '*/10 * * * *',                    -- 매 10분마다
  $$
  select net.http_post(
    url := 'https://<PROJECT_REF>.supabase.co/functions/v1/analyze-pending',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer <SERVICE_ROLE_KEY>'
    ),
    body := '{}'::jsonb
  );
  $$
);

-- 등록된 작업 확인
select * from cron.job where jobname = 'analyze-pending-files';
