-- ============================================================
-- Edge Function 호출 주기를 10분 → 2분으로 변경
-- Supabase 대시보드 → SQL Editor → New query 에 붙여넣기 전에,
-- 아래 두 곳을 본인 값으로 바꿔주세요.
--   <PROJECT_REF>      → Project URL의 https:// 뒤, .supabase.co 앞 부분
--   <SERVICE_ROLE_KEY> → Project Settings → API Keys의 "secret" 키 (sb_secret_...)
-- ============================================================

-- 기존 작업 제거
select cron.unschedule('analyze-pending-files')
where exists (
  select 1 from cron.job where jobname = 'analyze-pending-files'
);

-- 2분마다 analyze-pending Edge Function을 호출하는 작업으로 재등록
select cron.schedule(
  'analyze-pending-files',           -- 작업 이름
  '*/2 * * * *',                     -- 매 2분마다
  $$
  select net.http_post(
    url := 'https://<PROJECT_REF>.supabase.co/functions/v1/analyze-pending',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer <SERVICE_ROLE_KEY>'
    ),
    body := '{}'::jsonb
  );
  $$
);

-- 등록된 작업 확인 (schedule 컬럼이 '*/2 * * * *' 로 보이면 성공)
select * from cron.job where jobname = 'analyze-pending-files';
