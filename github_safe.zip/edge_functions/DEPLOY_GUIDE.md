# Gemini 분석 Edge Function — 배포 가이드

## 이 함수가 하는 일

`files` 테이블에서 `status = 'pending'`인 행(메일 수집기가 올려둔, 아직
분석 안 한 PDF)을 찾아서, Gemini에게 PDF를 직접 보내 분석시키고, 그 결과
(Invoice No, B/L No, 구매처, 금액 등)를 같은 행에 채운 뒤 `status`를
`'analyzed'`로 바꿉니다. 한 번 호출에 최대 10개 파일까지 처리합니다.

---

## 1단계: Supabase CLI 설치 (최초 1회)

Edge Function은 SQL Editor에 붙여넣는 방식이 아니라, 별도의 도구(Supabase CLI)로
배포합니다.

1. [supabase.com/docs/guides/cli](https://supabase.com/docs/guides/cli) 접속
2. Windows용 설치 방법 확인 (보통 `scoop install supabase` 또는 직접 실행파일
   다운로드) — 안내가 막히면 캡처해서 문의해주세요.

---

## 2단계: 로그인 및 프로젝트 연결

명령 프롬프트(cmd)에서 아래를 순서대로 입력합니다.

```
supabase login
```

브라우저가 열리면서 로그인하라고 뜹니다. 로그인하면 자동으로 명령창으로
돌아옵니다.

```
supabase link --project-ref mplvptnshltlubulxykw
```

(`mplvptnshltlubulxykw`는 EXPORT TOOL 프로젝트의 고유 ID — Project URL의
`https://` 뒤, `.supabase.co` 앞 부분과 같습니다.)

---

## 3단계: 함수 코드 배치

`analyze-pending` 폴더(이 안의 `index.ts` 파일)를 아래 구조로 옮겨주세요.

```
(아무 작업 폴더)/
└── supabase/
    └── functions/
        └── analyze-pending/
            └── index.ts
```

즉 `supabase` 폴더를 새로 만들고, 그 안에 `functions` 폴더, 그 안에
`analyze-pending` 폴더를 만들고, 거기에 `index.ts`를 넣으면 됩니다.

---

## 4단계: 환경변수(Secrets) 등록

Edge Function이 사용할 비밀값들을 등록합니다. 명령 프롬프트에서:

```
supabase secrets set SUPABASE_URL=https://mplvptnshltlubulxykw.supabase.co
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=여기에_service_role_키
supabase secrets set GEMINI_API_KEY=여기에_Gemini_API_키
```

★ `SUPABASE_SERVICE_ROLE_KEY`는 `sb_publishable_...`가 아니라
**`sb_secret_...`로 시작하는 키**입니다 (Project Settings → API Keys에서
"service_role" 또는 "secret" 항목 — 처음에 만드실 때 `sb_secret_2yrUlFtrZ...`
라고 알려주셨던 그 키입니다).

★ `GEMINI_API_KEY`는 지금 export_tool.html에서 쓰고 계신 그 키와 동일하게
넣으면 됩니다.

---

## 5단계: 배포

```
supabase functions deploy analyze-pending
```

성공하면 함수 URL이 나옵니다. 보통 이런 형태입니다.

```
https://mplvptnshltlubulxykw.supabase.co/functions/v1/analyze-pending
```

---

## 6단계: 한 번 직접 호출해서 테스트

브라우저 주소창에 위 URL을 그대로 입력해서 들어가거나(GET 요청도 허용되도록
만들어뒀습니다), 또는 명령 프롬프트에서:

```
curl https://mplvptnshltlubulxykw.supabase.co/functions/v1/analyze-pending
```

성공하면 이런 응답이 보입니다.

```json
{"message":"분석 완료","total":10,"success":10,"error":0}
```

Supabase Table Editor → `files` 테이블에서 `status`가 `analyzed`로 바뀌고,
`invoice_no`, `bl_no` 등 컬럼이 채워졌는지 확인해주세요.

---

## 7단계: 자동으로 주기 실행되도록 스케줄 등록 (pg_cron)

`schedule_analysis.sql` 파일을 SQL Editor의 **새 쿼리**에 붙여넣고 실행하면,
10분마다 이 함수가 자동으로 호출되도록 등록됩니다. (URL 안의 프로젝트 ID와
service_role 키를 본인 값으로 바꿔야 합니다 — 파일 안에 표시되어 있습니다.)

---

## 문제가 생기면

- **"함수를 찾을 수 없습니다" 류의 오류** → 3단계 폴더 구조가 정확한지 확인
- **"Gemini API 오류"** → GEMINI_API_KEY가 정확히 등록됐는지 확인
- **"권한 오류" (RLS 관련)** → SUPABASE_SERVICE_ROLE_KEY를 정확히 등록했는지
  확인 (publishable 키를 잘못 넣으면 권한 부족으로 실패합니다)

## 참고: PDF 텍스트 보강 검증의 한계

이 함수는 export_tool.html과 같은 방식으로, EXPORT 문서의 핵심 필드를 PDF
텍스트에서 직접 재추출해 Gemini 응답을 보강/교정합니다. 다만 Edge Function
환경(Deno)에는 브라우저의 pdf.js 같은 정교한 PDF 파서가 없어서, 텍스트
추출이 일부 PDF(특히 이미지로 스캔되었거나 폰트가 압축된 PDF)에서는 실패할
수 있습니다. 이 경우에도 Gemini의 PDF 직접 분석 결과만으로 정상 동작하며,
보강 검증은 "되면 더 정확해지는 보너스"로 동작하도록 만들어졌습니다.
